package com.tw;

public class Printer {
    public void print(String message) {
        System.out.println(message);
    }
}
