package com.tw;

import java.util.Scanner;

public class StringReader {
    private Scanner scanner=new Scanner(System.in);

    public String read() {
        String input = scanner.next();
            return input;
        }


}
